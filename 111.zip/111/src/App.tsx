import Hero from './components/Hero'
import Projects from './components/Projects'
import Blog from './components/Blog'
import VisitorStats from './components/VisitorStats'
import MessageBoard from './components/MessageBoard'
import ThemeToggle from './components/ThemeToggle'
import LanguageToggle from './components/LanguageToggle'
import { useTheme } from './context/ThemeContext'

function App() {
  const { theme } = useTheme()

  return (
    <div 
      className="min-h-screen transition-colors duration-300"
      style={{
        backgroundColor: theme === 'dark' ? '#0a0a0a' : '#f5f5f5',
        color: theme === 'dark' ? '#ffffff' : '#1a1a1a'
      }}
    >
      {/* 控制按钮组 - 固定在右上角 */}
      <div className="fixed top-4 right-4 z-50 flex items-center gap-2">
        <LanguageToggle />
        <ThemeToggle />
      </div>
      <Hero />
      <Projects />
      <Blog />
      <VisitorStats />
      <MessageBoard />
    </div>
  )
}

export default App
