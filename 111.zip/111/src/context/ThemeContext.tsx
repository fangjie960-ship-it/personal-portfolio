import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react'

// 主题类型
type Theme = 'dark' | 'light'

// 主题上下文类型
interface ThemeContextType {
  theme: Theme
  toggleTheme: () => void
}

// 创建上下文
const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

// 应用主题到 DOM
const applyTheme = (theme: Theme) => {
  const root = document.documentElement
  if (theme === 'dark') {
    root.classList.add('dark')
    root.classList.remove('light')
  } else {
    root.classList.add('light')
    root.classList.remove('dark')
  }
  console.log('Theme applied:', theme, 'Classes:', root.className)
}

// 主题提供者组件
export const ThemeProvider = ({ children }: { children: ReactNode }) => {
  // 从 localStorage 读取主题偏好，默认深色
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem('theme') as Theme
    const initial = saved || 'dark'
    // 立即应用初始主题
    applyTheme(initial)
    return initial
  })

  // 切换主题
  const toggleTheme = useCallback(() => {
    setTheme((prev) => {
      const newTheme = prev === 'dark' ? 'light' : 'dark'
      console.log('Toggling from', prev, 'to', newTheme)
      return newTheme
    })
  }, [])

  // 主题变化时更新 DOM 和 localStorage
  useEffect(() => {
    console.log('Theme effect triggered:', theme)
    localStorage.setItem('theme', theme)
    applyTheme(theme)
  }, [theme])

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  )
}

// 自定义 hook 使用主题
export const useTheme = () => {
  const context = useContext(ThemeContext)
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider')
  }
  return context
}
