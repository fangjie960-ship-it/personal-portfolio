import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { useTheme } from '../context/ThemeContext'

// 访问统计组件
const VisitorStats = () => {
  const { theme } = useTheme()
  const isDark = theme === 'dark'
  const [stats, setStats] = useState({
    totalVisits: 0,
    uniqueVisitors: 0,
    todayVisits: 0,
    lastVisit: ''
  })

  useEffect(() => {
    // 获取或初始化统计数据
    const stored = localStorage.getItem('visitorStats')
    let data = stored ? JSON.parse(stored) : {
      totalVisits: 0,
      uniqueVisitors: 0,
      todayVisits: 0,
      lastVisit: '',
      visitorIds: [],
      dailyVisits: {}
    }

    // 获取今天日期
    const today = new Date().toISOString().split('T')[0]
    
    // 更新统计数据
    data.totalVisits += 1
    
    // 如果是新的一天，重置今日访问数
    if (!data.dailyVisits) data.dailyVisits = {}
    if (data.dailyVisits[today] === undefined) {
      data.dailyVisits[today] = 0
    }
    data.dailyVisits[today] += 1
    data.todayVisits = data.dailyVisits[today]

    // 检查是否为新访客（简单判断：如果 lastVisit 为空或上次访问超过30分钟前）
    const now = new Date()
    const lastVisit = data.lastVisit ? new Date(data.lastVisit) : null
    const isNewVisitor = !lastVisit || (now.getTime() - lastVisit.getTime()) > 30 * 60 * 1000

    if (isNewVisitor) {
      data.uniqueVisitors += 1
    }

    // 记录访问时间
    data.lastVisit = now.toISOString()

    // 保存到 localStorage
    localStorage.setItem('visitorStats', JSON.stringify(data))

    // 更新显示状态
    setStats({
      totalVisits: data.totalVisits,
      uniqueVisitors: data.uniqueVisitors,
      todayVisits: data.todayVisits,
      lastVisit: data.lastVisit
    })
  }, [])

  const formatDate = (dateString: string) => {
    if (!dateString) return '从未访问'
    const date = new Date(dateString)
    return date.toLocaleString('zh-CN')
  }

  return (
    <motion.section
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
      className="py-20 px-4 sm:px-6 lg:px-8"
      style={{ backgroundColor: isDark ? '#0a0a0a' : '#f5f5f5' }}
    >
      <div className="max-w-6xl mx-auto">
        {/* 标题 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-green-400 to-teal-400 bg-clip-text text-transparent">
              访问统计
            </span>
          </h2>
          <p className="max-w-2xl mx-auto" style={{ color: isDark ? '#9ca3af' : '#6b7280' }}>
            感谢每一位访客的到访，以下是网站的访问数据
          </p>
        </motion.div>

        {/* 统计卡片 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* 总访问量 */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: 0 }}
            viewport={{ once: true }}
            className="rounded-xl p-6 text-center"
            style={{
              backgroundColor: isDark ? '#111827' : '#ffffff',
              border: `1px solid ${isDark ? '#374151' : '#e5e7eb'}`
            }}
          >
            <div 
              className="w-12 h-12 rounded-full mx-auto mb-4 flex items-center justify-center"
              style={{ backgroundColor: isDark ? '#1f2937' : '#f3f4f6' }}
            >
              <svg className="w-6 h-6" fill="none" stroke="#10b981" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
            </div>
            <div className="text-3xl font-bold mb-1" style={{ color: isDark ? '#ffffff' : '#111827' }}>
              {stats.totalVisits.toLocaleString()}
            </div>
            <div className="text-sm" style={{ color: isDark ? '#9ca3af' : '#6b7280' }}>
              总访问量
            </div>
          </motion.div>

          {/* 今日访问 */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: 0.1 }}
            viewport={{ once: true }}
            className="rounded-xl p-6 text-center"
            style={{
              backgroundColor: isDark ? '#111827' : '#ffffff',
              border: `1px solid ${isDark ? '#374151' : '#e5e7eb'}`
            }}
          >
            <div 
              className="w-12 h-12 rounded-full mx-auto mb-4 flex items-center justify-center"
              style={{ backgroundColor: isDark ? '#1f2937' : '#f3f4f6' }}
            >
              <svg className="w-6 h-6" fill="none" stroke="#f59e0b" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
            </div>
            <div className="text-3xl font-bold mb-1" style={{ color: isDark ? '#ffffff' : '#111827' }}>
              {stats.todayVisits}
            </div>
            <div className="text-sm" style={{ color: isDark ? '#9ca3af' : '#6b7280' }}>
              今日访问
            </div>
          </motion.div>

          {/* 独立访客 */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: 0.2 }}
            viewport={{ once: true }}
            className="rounded-xl p-6 text-center"
            style={{
              backgroundColor: isDark ? '#111827' : '#ffffff',
              border: `1px solid ${isDark ? '#374151' : '#e5e7eb'}`
            }}
          >
            <div 
              className="w-12 h-12 rounded-full mx-auto mb-4 flex items-center justify-center"
              style={{ backgroundColor: isDark ? '#1f2937' : '#f3f4f6' }}
            >
              <svg className="w-6 h-6" fill="none" stroke="#8b5cf6" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
            <div className="text-3xl font-bold mb-1" style={{ color: isDark ? '#ffffff' : '#111827' }}>
              {stats.uniqueVisitors}
            </div>
            <div className="text-sm" style={{ color: isDark ? '#9ca3af' : '#6b7280' }}>
              独立访客
            </div>
          </motion.div>

          {/* 最后访问 */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: 0.3 }}
            viewport={{ once: true }}
            className="rounded-xl p-6 text-center"
            style={{
              backgroundColor: isDark ? '#111827' : '#ffffff',
              border: `1px solid ${isDark ? '#374151' : '#e5e7eb'}`
            }}
          >
            <div 
              className="w-12 h-12 rounded-full mx-auto mb-4 flex items-center justify-center"
              style={{ backgroundColor: isDark ? '#1f2937' : '#f3f4f6' }}
            >
              <svg className="w-6 h-6" fill="none" stroke="#ec4899" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div className="text-sm font-medium mb-1" style={{ color: isDark ? '#ffffff' : '#111827' }}>
              {formatDate(stats.lastVisit)}
            </div>
            <div className="text-sm" style={{ color: isDark ? '#9ca3af' : '#6b7280' }}>
              最后访问时间
            </div>
          </motion.div>
        </div>

        {/* 说明文字 */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center text-xs mt-8"
          style={{ color: isDark ? '#6b7280' : '#9ca3af' }}
        >
          注：统计数据基于浏览器本地存储，仅供参考
        </motion.p>
      </div>
    </motion.section>
  )
}

export default VisitorStats
