import { useLanguage } from '../context/LanguageContext'

// 语言切换按钮组件
const LanguageToggle = () => {
  const { language, setLanguage } = useLanguage()

  const toggleLanguage = () => {
    setLanguage(language === 'zh' ? 'en' : 'zh')
  }

  return (
    <button
      onClick={toggleLanguage}
      className="px-3 py-2 rounded-lg bg-gray-200 dark:bg-gray-800 hover:bg-gray-300 dark:hover:bg-gray-700 transition-colors text-sm font-medium text-gray-700 dark:text-gray-300"
      aria-label={language === 'zh' ? 'Switch to English' : '切换到中文'}
    >
      {language === 'zh' ? 'EN' : '中'}
    </button>
  )
}

export default LanguageToggle
