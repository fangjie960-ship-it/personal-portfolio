import { motion } from 'framer-motion'
import { useProjects, Project } from '../data/projects'
import { useLanguage } from '../context/LanguageContext'
import { useTheme } from '../context/ThemeContext'

// 单个项目卡片组件
const ProjectCard = ({ project, index, t, isDark }: { project: Project; index: number; t: (key: string) => string; isDark: boolean }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
      className="group rounded-xl overflow-hidden border hover:border-purple-500/50 transition-all duration-300"
      style={{
        backgroundColor: isDark ? '#111827' : '#ffffff',
        borderColor: isDark ? '#374151' : '#e5e7eb'
      }}
    >
      {/* 项目截图 */}
      <div className="relative h-48 overflow-hidden" style={{ backgroundColor: isDark ? '#374151' : '#d1d5db' }}>
        {project.image ? (
          <img
            src={project.image}
            alt={project.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center" style={{ backgroundColor: isDark ? '#374151' : '#d1d5db' }}>
            <div className="w-20 h-20 rounded-lg" style={{ backgroundColor: isDark ? '#4b5563' : '#9ca3af' }} />
          </div>
        )}
        {/* 悬停遮罩 */}
        <div className="absolute inset-0 bg-gradient-to-t via-transparent to-transparent opacity-60" style={{ background: isDark ? 'linear-gradient(to top, #111827, transparent, transparent)' : 'linear-gradient(to top, #ffffff, transparent, transparent)' }} />
      </div>

      {/* 项目信息 */}
      <div className="p-6">
        {/* 标题 */}
        <h3 className="text-xl font-bold mb-2 group-hover:text-purple-400 transition-colors" style={{ color: isDark ? '#ffffff' : '#111827' }}>
          {project.name}
        </h3>

        {/* 描述 */}
        <p className="text-sm mb-4 line-clamp-2" style={{ color: isDark ? '#9ca3af' : '#4b5563' }}>
          {project.description}
        </p>

        {/* 技术栈标签 */}
        <div className="flex flex-wrap gap-2 mb-4">
          {project.techStack.map((tech) => (
            <span
              key={tech}
              className="px-3 py-1 text-xs font-medium rounded-full border"
              style={{
                backgroundColor: isDark ? '#1f2937' : '#f3f4f6',
                color: isDark ? '#c4b5fd' : '#7c3aed',
                borderColor: isDark ? '#374151' : '#e5e7eb'
              }}
            >
              {tech}
            </span>
          ))}
        </div>

        {/* 项目链接 */}
        <a
          href={project.link}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center text-sm transition-colors"
          style={{ color: isDark ? '#a78bfa' : '#7c3aed' }}
        >
          {t('projects.viewProject')}
          <svg
            className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M17 8l4 4m0 0l-4 4m4-4H3"
            />
          </svg>
        </a>
      </div>
    </motion.div>
  )
}

// Projects 组件 - 项目展示列表
const Projects = () => {
  const { t, language } = useLanguage()
  const { theme } = useTheme()
  const projects = useProjects()
  const isDark = theme === 'dark'

  return (
    <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* 标题 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              {t('projects.title')}
            </span>
          </h2>
          <p className="max-w-2xl mx-auto" style={{ color: isDark ? '#9ca3af' : '#6b7280' }}>
            {t('projects.subtitle')}
          </p>
        </motion.div>

        {/* 项目网格 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <ProjectCard key={`${language}-${project.id}`} project={project} index={index} t={t} isDark={theme === 'dark'} />
          ))}
        </div>
      </div>
    </section>
  )
}

export default Projects
