import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useTheme } from '../context/ThemeContext'
import { useLanguage } from '../context/LanguageContext'

// 留言类型
type MessageCategory = 'praise' | 'suggestion' | 'question' | 'criticism' | 'other'

// 留言数据接口
interface Message {
  id: string
  name: string
  content: string
  category: MessageCategory
  timestamp: string
}

// 分类配置
const categories: { key: MessageCategory; label: string; color: string; icon: string }[] = [
  { key: 'praise', label: '赞赏', color: '#10b981', icon: '👏' },
  { key: 'suggestion', label: '建议', color: '#f59e0b', icon: '💡' },
  { key: 'question', label: '疑问', color: '#3b82f6', icon: '❓' },
  { key: 'criticism', label: '批评', color: '#ef4444', icon: '🔧' },
  { key: 'other', label: '其他', color: '#6b7280', icon: '📝' }
]

// 留言板组件
const MessageBoard = () => {
  const { theme } = useTheme()
  const { language } = useLanguage()
  const isDark = theme === 'dark'

  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState({ name: '', content: '', category: 'other' as MessageCategory })
  const [activeFilter, setActiveFilter] = useState<MessageCategory | 'all'>('all')
  const [isSubmitting, setIsSubmitting] = useState(false)

  // 从 localStorage 加载留言
  useEffect(() => {
    const stored = localStorage.getItem('messages')
    if (stored) {
      setMessages(JSON.parse(stored))
    }
  }, [])

  // 保存留言到 localStorage
  const saveMessages = (msgs: Message[]) => {
    localStorage.setItem('messages', JSON.stringify(msgs))
    setMessages(msgs)
  }

  // 提交留言
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.name.trim() || !newMessage.content.trim()) return

    setIsSubmitting(true)

    const message: Message = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      name: newMessage.name.trim(),
      content: newMessage.content.trim(),
      category: newMessage.category,
      timestamp: new Date().toISOString()
    }

    const updatedMessages = [message, ...messages]
    saveMessages(updatedMessages)

    // 重置表单
    setNewMessage({ name: '', content: '', category: 'other' })
    setIsSubmitting(false)

    // 显示成功提示
    alert(language === 'zh' ? '留言提交成功！' : 'Message submitted successfully!')
  }

  // 删除留言（仅用于演示）
  const handleDelete = (id: string) => {
    if (confirm(language === 'zh' ? '确定要删除这条留言吗？' : 'Are you sure you want to delete this message?')) {
      const updatedMessages = messages.filter(m => m.id !== id)
      saveMessages(updatedMessages)
    }
  }

  // 过滤留言
  const filteredMessages = activeFilter === 'all' 
    ? messages 
    : messages.filter(m => m.category === activeFilter)

  // 格式化时间
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp)
    return date.toLocaleString(language === 'zh' ? 'zh-CN' : 'en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  return (
    <motion.section
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
      className="py-20 px-4 sm:px-6 lg:px-8"
      style={{ backgroundColor: isDark ? '#0a0a0a' : '#f5f5f5' }}
    >
      <div className="max-w-4xl mx-auto">
        {/* 标题 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-pink-400 to-rose-400 bg-clip-text text-transparent">
              {language === 'zh' ? '留言板' : 'Message Board'}
            </span>
          </h2>
          <p className="max-w-2xl mx-auto" style={{ color: isDark ? '#9ca3af' : '#6b7280' }}>
            {language === 'zh' ? '欢迎留下您的想法、建议或问题' : 'Welcome to leave your thoughts, suggestions or questions'}
          </p>
        </motion.div>

        {/* 留言表单 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          viewport={{ once: true }}
          className="rounded-xl p-6 mb-8"
          style={{
            backgroundColor: isDark ? '#111827' : '#ffffff',
            border: `1px solid ${isDark ? '#374151' : '#e5e7eb'}`
          }}
        >
          <h3 className="text-xl font-bold mb-4" style={{ color: isDark ? '#ffffff' : '#111827' }}>
            {language === 'zh' ? '发表留言' : 'Leave a Message'}
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: isDark ? '#9ca3af' : '#4b5563' }}>
                  {language === 'zh' ? '您的昵称' : 'Your Name'}
                </label>
                <input
                  type="text"
                  value={newMessage.name}
                  onChange={(e) => setNewMessage({ ...newMessage, name: e.target.value })}
                  placeholder={language === 'zh' ? '请输入昵称' : 'Enter your name'}
                  className="w-full px-4 py-2 rounded-lg outline-none transition-colors"
                  style={{
                    backgroundColor: isDark ? '#1f2937' : '#f3f4f6',
                    color: isDark ? '#ffffff' : '#111827',
                    border: `1px solid ${isDark ? '#374151' : '#e5e7eb'}`
                  }}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: isDark ? '#9ca3af' : '#4b5563' }}>
                  {language === 'zh' ? '留言类型' : 'Message Type'}
                </label>
                <select
                  value={newMessage.category}
                  onChange={(e) => setNewMessage({ ...newMessage, category: e.target.value as MessageCategory })}
                  className="w-full px-4 py-2 rounded-lg outline-none transition-colors"
                  style={{
                    backgroundColor: isDark ? '#1f2937' : '#f3f4f6',
                    color: isDark ? '#ffffff' : '#111827',
                    border: `1px solid ${isDark ? '#374151' : '#e5e7eb'}`
                  }}
                >
                  {categories.map(cat => (
                    <option key={cat.key} value={cat.key}>
                      {cat.icon} {cat.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: isDark ? '#9ca3af' : '#4b5563' }}>
                {language === 'zh' ? '留言内容' : 'Message Content'}
              </label>
              <textarea
                value={newMessage.content}
                onChange={(e) => setNewMessage({ ...newMessage, content: e.target.value })}
                placeholder={language === 'zh' ? '请输入您的留言...' : 'Enter your message...'}
                rows={4}
                className="w-full px-4 py-2 rounded-lg outline-none transition-colors resize-none"
                style={{
                  backgroundColor: isDark ? '#1f2937' : '#f3f4f6',
                  color: isDark ? '#ffffff' : '#111827',
                  border: `1px solid ${isDark ? '#374151' : '#e5e7eb'}`
                }}
                required
              />
            </div>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2 rounded-lg font-medium transition-colors disabled:opacity-50"
              style={{
                backgroundColor: isDark ? '#f472b6' : '#ec4899',
                color: '#ffffff'
              }}
            >
              {isSubmitting 
                ? (language === 'zh' ? '提交中...' : 'Submitting...') 
                : (language === 'zh' ? '提交留言' : 'Submit Message')}
            </button>
          </form>
        </motion.div>

        {/* 分类过滤 */}
        <div className="flex flex-wrap gap-2 mb-6">
          <button
            onClick={() => setActiveFilter('all')}
            className="px-4 py-2 rounded-full text-sm font-medium transition-colors"
            style={{
              backgroundColor: activeFilter === 'all' ? (isDark ? '#f472b6' : '#ec4899') : (isDark ? '#1f2937' : '#f3f4f6'),
              color: activeFilter === 'all' ? '#ffffff' : (isDark ? '#9ca3af' : '#6b7280')
            }}
          >
            {language === 'zh' ? '全部' : 'All'} ({messages.length})
          </button>
          {categories.map(cat => {
            const count = messages.filter(m => m.category === cat.key).length
            return (
              <button
                key={cat.key}
                onClick={() => setActiveFilter(cat.key)}
                className="px-4 py-2 rounded-full text-sm font-medium transition-colors"
                style={{
                  backgroundColor: activeFilter === cat.key ? cat.color : (isDark ? '#1f2937' : '#f3f4f6'),
                  color: activeFilter === cat.key ? '#ffffff' : (isDark ? '#9ca3af' : '#6b7280')
                }}
              >
                {cat.icon} {cat.label} ({count})
              </button>
            )
          })}
        </div>

        {/* 留言列表 */}
        <div className="space-y-4">
          <AnimatePresence mode="popLayout">
            {filteredMessages.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-12"
                style={{ color: isDark ? '#6b7280' : '#9ca3af' }}
              >
                {language === 'zh' ? '暂无留言，来发表第一条吧！' : 'No messages yet, be the first to leave one!'}
              </motion.div>
            ) : (
              filteredMessages.map((message, index) => {
                const category = categories.find(c => c.key === message.category)
                return (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                    className="rounded-xl p-5"
                    style={{
                      backgroundColor: isDark ? '#111827' : '#ffffff',
                      border: `1px solid ${isDark ? '#374151' : '#e5e7eb'}`,
                      borderLeft: `4px solid ${category?.color || '#6b7280'}`
                    }}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <span className="text-lg">{category?.icon}</span>
                        <span className="font-medium" style={{ color: isDark ? '#ffffff' : '#111827' }}>
                          {message.name}
                        </span>
                        <span
                          className="px-2 py-0.5 rounded text-xs"
                          style={{
                            backgroundColor: category?.color + '20',
                            color: category?.color
                          }}
                        >
                          {category?.label}
                        </span>
                      </div>
                      <span className="text-xs" style={{ color: isDark ? '#6b7280' : '#9ca3af' }}>
                        {formatTime(message.timestamp)}
                      </span>
                    </div>
                    <p className="text-sm leading-relaxed" style={{ color: isDark ? '#d1d5db' : '#374151' }}>
                      {message.content}
                    </p>
                    {/* 删除按钮（演示用） */}
                    <button
                      onClick={() => handleDelete(message.id)}
                      className="mt-3 text-xs transition-colors"
                      style={{ color: isDark ? '#6b7280' : '#9ca3af' }}
                    >
                      {language === 'zh' ? '删除' : 'Delete'}
                    </button>
                  </motion.div>
                )
              })
            )}
          </AnimatePresence>
        </div>

        {/* 统计信息 */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="mt-8 text-center text-xs"
          style={{ color: isDark ? '#6b7280' : '#9ca3af' }}
        >
          {language === 'zh' 
            ? `共 ${messages.length} 条留言 · 赞赏 ${messages.filter(m => m.category === 'praise').length} · 建议 ${messages.filter(m => m.category === 'suggestion').length} · 疑问 ${messages.filter(m => m.category === 'question').length} · 批评 ${messages.filter(m => m.category === 'criticism').length}`
            : `Total ${messages.length} messages · Praise ${messages.filter(m => m.category === 'praise').length} · Suggestions ${messages.filter(m => m.category === 'suggestion').length} · Questions ${messages.filter(m => m.category === 'question').length} · Criticism ${messages.filter(m => m.category === 'criticism').length}`
          }
        </motion.div>
      </div>
    </motion.section>
  )
}

export default MessageBoard
