import { motion } from 'framer-motion'
import { useBlogPosts, BlogPost } from '../data/blog'
import { useLanguage } from '../context/LanguageContext'
import { useTheme } from '../context/ThemeContext'

// 单个博客文章卡片组件
const BlogCard = ({ post, index, t, isDark }: { post: BlogPost; index: number; t: (key: string) => string; isDark: boolean }) => {
  return (
    <motion.article
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
      className="group rounded-xl p-6 border hover:border-blue-500/50 transition-all duration-300"
      style={{
        backgroundColor: isDark ? '#111827' : '#ffffff',
        borderColor: isDark ? '#374151' : '#e5e7eb'
      }}
    >
      {/* 日期和阅读时间 */}
      <div className="flex items-center gap-4 text-sm mb-4" style={{ color: isDark ? '#6b7280' : '#9ca3af' }}>
        <span>{post.date}</span>
        <span className="w-1 h-1 rounded-full" style={{ backgroundColor: isDark ? '#6b7280' : '#9ca3af' }} />
        <span>{post.readTime} {t('blog.minRead')}</span>
      </div>

      {/* 标题 */}
      <h3 className="text-xl font-bold mb-3 group-hover:text-blue-400 transition-colors line-clamp-2" style={{ color: isDark ? '#ffffff' : '#111827' }}>
        {post.title}
      </h3>

      {/* 描述 */}
      <p className="text-sm mb-4 line-clamp-3 leading-relaxed" style={{ color: isDark ? '#9ca3af' : '#4b5563' }}>
        {post.description}
      </p>

      {/* 技术栈标签 */}
      <div className="flex flex-wrap gap-2 mb-4">
        {post.techStack.map((tech) => (
          <span
            key={tech}
            className="px-3 py-1 text-xs font-medium rounded-full border"
            style={{
              backgroundColor: isDark ? '#1f2937' : '#f3f4f6',
              color: isDark ? '#93c5fd' : '#2563eb',
              borderColor: isDark ? '#374151' : '#e5e7eb'
            }}
          >
            {tech}
          </span>
        ))}
      </div>

      {/* 阅读更多链接 */}
      <a
        href={post.link}
        className="inline-flex items-center text-sm transition-colors"
        style={{ color: isDark ? '#60a5fa' : '#2563eb' }}
      >
        {t('blog.readMore')}
        <svg
          className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M17 8l4 4m0 0l-4 4m4-4H3"
          />
        </svg>
      </a>
    </motion.article>
  )
}

// Blog 组件 - 博客文章列表
const Blog = () => {
  const { t, language } = useLanguage()
  const { theme } = useTheme()
  const blogPosts = useBlogPosts()
  const isDark = theme === 'dark'

  return (
    <section id="blog" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* 标题 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
              {t('blog.title')}
            </span>
          </h2>
          <p className="max-w-2xl mx-auto" style={{ color: isDark ? '#9ca3af' : '#6b7280' }}>
            {t('blog.subtitle')}
          </p>
        </motion.div>

        {/* 文章网格 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {blogPosts.map((post, index) => (
            <BlogCard key={`${language}-${post.id}`} post={post} index={index} t={t} isDark={theme === 'dark'} />
          ))}
        </div>
      </div>
    </section>
  )
}

export default Blog
