import { useTheme } from '../context/ThemeContext'

// 主题切换按钮组件
const ThemeToggle = () => {
  const { theme, toggleTheme } = useTheme()

  const handleClick = () => {
    toggleTheme()
  }

  return (
    <button
      onClick={handleClick}
      style={{
        padding: '8px',
        borderRadius: '8px',
        cursor: 'pointer',
        backgroundColor: theme === 'dark' ? '#374151' : '#e5e7eb',
        border: '1px solid ' + (theme === 'dark' ? '#4b5563' : '#d1d5db'),
        pointerEvents: 'auto',
        zIndex: 9999
      }}
      title={theme === 'dark' ? 'Switch to Light' : 'Switch to Dark'}
    >
      {theme === 'dark' ? (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fbbf24" strokeWidth="2">
          <circle cx="12" cy="12" r="5"/>
          <path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/>
        </svg>
      ) : (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#374151" strokeWidth="2">
          <path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/>
        </svg>
      )}
    </button>
  )
}

export default ThemeToggle
