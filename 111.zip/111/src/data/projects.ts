import { useLanguage } from '../context/LanguageContext'

// 项目数据类型定义
export interface Project {
  id: number
  name: string
  description: string
  image: string
  techStack: string[]
  link: string
}

// 中文项目数据
const projectsZh: Project[] = [
  {
    id: 1,
    name: '电商平台',
    description: '基于 React 和 Node.js 的全栈电商解决方案，支持商品管理、购物车、支付等功能',
    image: '',
    techStack: ['React', 'Node.js', 'MongoDB', 'Stripe'],
    link: 'https://github.com'
  },
  {
    id: 2,
    name: '任务管理应用',
    description: '简洁高效的任务管理工具，支持拖拽排序、标签分类和团队协作',
    image: '',
    techStack: ['TypeScript', 'Vue 3', 'Pinia', 'Tailwind CSS'],
    link: 'https://github.com'
  },
  {
    id: 3,
    name: '数据分析仪表板',
    description: '可视化数据仪表板，实时展示业务指标和数据分析图表',
    image: '',
    techStack: ['React', 'D3.js', 'Python', 'FastAPI'],
    link: 'https://github.com'
  },
  {
    id: 4,
    name: '社交媒体应用',
    description: '支持实时聊天、动态发布、点赞评论的社交平台',
    image: '',
    techStack: ['Next.js', 'Socket.io', 'PostgreSQL', 'Redis'],
    link: 'https://github.com'
  },
  {
    id: 5,
    name: '在线教育平台',
    description: '支持视频课程、直播教学、作业管理的在线学习系统',
    image: '',
    techStack: ['React', 'GraphQL', 'AWS', 'Docker'],
    link: 'https://github.com'
  },
  {
    id: 6,
    name: '个人博客系统',
    description: '基于 Markdown 的博客系统，支持主题切换、评论系统和 SEO 优化',
    image: '',
    techStack: ['Astro', 'MDX', 'Vercel', 'Tailwind CSS'],
    link: 'https://github.com'
  }
]

// 英文项目数据
const projectsEn: Project[] = [
  {
    id: 1,
    name: 'E-commerce Platform',
    description: 'Full-stack e-commerce solution based on React and Node.js, supporting product management, shopping cart, payment and more',
    image: '',
    techStack: ['React', 'Node.js', 'MongoDB', 'Stripe'],
    link: 'https://github.com'
  },
  {
    id: 2,
    name: 'Task Management App',
    description: 'Simple and efficient task management tool with drag-and-drop sorting, tag categorization and team collaboration',
    image: '',
    techStack: ['TypeScript', 'Vue 3', 'Pinia', 'Tailwind CSS'],
    link: 'https://github.com'
  },
  {
    id: 3,
    name: 'Data Analytics Dashboard',
    description: 'Visual data dashboard displaying business metrics and data analysis charts in real-time',
    image: '',
    techStack: ['React', 'D3.js', 'Python', 'FastAPI'],
    link: 'https://github.com'
  },
  {
    id: 4,
    name: 'Social Media App',
    description: 'Social platform supporting real-time chat, post sharing, likes and comments',
    image: '',
    techStack: ['Next.js', 'Socket.io', 'PostgreSQL', 'Redis'],
    link: 'https://github.com'
  },
  {
    id: 5,
    name: 'Online Education Platform',
    description: 'Online learning system supporting video courses, live teaching and assignment management',
    image: '',
    techStack: ['React', 'GraphQL', 'AWS', 'Docker'],
    link: 'https://github.com'
  },
  {
    id: 6,
    name: 'Personal Blog System',
    description: 'Markdown-based blog system with theme switching, comment system and SEO optimization',
    image: '',
    techStack: ['Astro', 'MDX', 'Vercel', 'Tailwind CSS'],
    link: 'https://github.com'
  }
]

// Hook to get projects based on current language
export const useProjects = (): Project[] => {
  const { language } = useLanguage()
  return language === 'zh' ? projectsZh : projectsEn
}

// Export static projects for backward compatibility
export const projects = projectsZh
