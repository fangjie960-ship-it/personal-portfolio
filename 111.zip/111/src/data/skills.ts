// 技能数据类型定义
export interface Skill {
  name: string
  level: number // 1-100
}

// 技能分类
export interface SkillCategory {
  category: string
  skills: Skill[]
}

// 示例技能数据
export const skillCategories: SkillCategory[] = [
  {
    category: '前端开发',
    skills: [
      { name: 'React', level: 90 },
      { name: 'TypeScript', level: 85 },
      { name: 'Tailwind CSS', level: 88 }
    ]
  },
  {
    category: '后端开发',
    skills: [
      { name: 'Node.js', level: 75 },
      { name: 'Python', level: 80 }
    ]
  }
]
