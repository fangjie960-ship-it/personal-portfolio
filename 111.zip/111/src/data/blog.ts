import { useLanguage } from '../context/LanguageContext'

// 博客文章数据类型定义
export interface BlogPost {
  id: number
  title: string
  description: string
  techStack: string[]
  date: string
  readTime: string
  link: string
}

// 中文博客数据
const blogPostsZh: BlogPost[] = [
  {
    id: 1,
    title: '深入理解 React Hooks',
    description: '从 useState 到 useEffect，全面解析 React Hooks 的工作原理和最佳实践，帮助你写出更优雅的函数组件',
    techStack: ['React', 'JavaScript', '前端'],
    date: '2024-03-15',
    readTime: '8',
    link: '#'
  },
  {
    id: 2,
    title: 'TypeScript 高级类型技巧',
    description: '掌握泛型、条件类型、映射类型等高级特性，让你的代码类型更加安全和可维护',
    techStack: ['TypeScript', '前端'],
    date: '2024-03-10',
    readTime: '12',
    link: '#'
  },
  {
    id: 3,
    title: 'Tailwind CSS 实战指南',
    description: '从零开始学习实用优先的 CSS 框架，快速构建现代化的响应式界面设计',
    techStack: ['Tailwind CSS', 'CSS', '前端'],
    date: '2024-03-05',
    readTime: '10',
    link: '#'
  },
  {
    id: 4,
    title: 'Node.js 性能优化实践',
    description: '分享在实际项目中总结的性能优化经验，包括内存管理、异步处理和缓存策略',
    techStack: ['Node.js', '后端', '性能优化'],
    date: '2024-02-28',
    readTime: '15',
    link: '#'
  },
  {
    id: 5,
    title: '从零构建个人作品集网站',
    description: '记录使用 React + TypeScript + Vite 搭建个人网站的完整过程，包含设计思路和技术选型',
    techStack: ['React', 'TypeScript', 'Vite', 'Tailwind CSS'],
    date: '2024-02-20',
    readTime: '20',
    link: '#'
  },
  {
    id: 6,
    title: 'Git 工作流最佳实践',
    description: '团队协作中 Git 分支管理、提交规范和代码审查的实战经验分享',
    techStack: ['Git', '开发工具', '协作'],
    date: '2024-02-15',
    readTime: '6',
    link: '#'
  }
]

// 英文博客数据
const blogPostsEn: BlogPost[] = [
  {
    id: 1,
    title: 'Deep Dive into React Hooks',
    description: 'From useState to useEffect, comprehensive analysis of React Hooks principles and best practices to help you write more elegant functional components',
    techStack: ['React', 'JavaScript', 'Frontend'],
    date: '2024-03-15',
    readTime: '8',
    link: '#'
  },
  {
    id: 2,
    title: 'TypeScript Advanced Type Techniques',
    description: 'Master advanced features like generics, conditional types, and mapped types to make your code more type-safe and maintainable',
    techStack: ['TypeScript', 'Frontend'],
    date: '2024-03-10',
    readTime: '12',
    link: '#'
  },
  {
    id: 3,
    title: 'Tailwind CSS Practical Guide',
    description: 'Learn utility-first CSS framework from scratch to quickly build modern responsive interface designs',
    techStack: ['Tailwind CSS', 'CSS', 'Frontend'],
    date: '2024-03-05',
    readTime: '10',
    link: '#'
  },
  {
    id: 4,
    title: 'Node.js Performance Optimization',
    description: 'Sharing performance optimization experience from real projects, including memory management, async handling and caching strategies',
    techStack: ['Node.js', 'Backend', 'Performance'],
    date: '2024-02-28',
    readTime: '15',
    link: '#'
  },
  {
    id: 5,
    title: 'Building a Portfolio Website from Scratch',
    description: 'Documenting the complete process of building a personal website with React + TypeScript + Vite, including design ideas and technology choices',
    techStack: ['React', 'TypeScript', 'Vite', 'Tailwind CSS'],
    date: '2024-02-20',
    readTime: '20',
    link: '#'
  },
  {
    id: 6,
    title: 'Git Workflow Best Practices',
    description: 'Practical experience sharing on Git branch management, commit conventions and code review in team collaboration',
    techStack: ['Git', 'DevTools', 'Collaboration'],
    date: '2024-02-15',
    readTime: '6',
    link: '#'
  }
]

// Hook to get blog posts based on current language
export const useBlogPosts = (): BlogPost[] => {
  const { language } = useLanguage()
  return language === 'zh' ? blogPostsZh : blogPostsEn
}

// Export static blogPosts for backward compatibility
export const blogPosts = blogPostsZh
