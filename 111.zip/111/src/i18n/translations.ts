// 语言类型
type Language = 'zh' | 'en'

// 翻译内容
interface Translations {
  [key: string]: string | Translations
}

const translations: Record<Language, Translations> = {
  zh: {
    // Hero 区域
    hero: {
      title: '你好我是开发者🍅酱',
      subtitle: '热爱创造优雅的数字体验，专注于构建高性能、用户友好的 Web 应用程序。让我们一起将想法转化为现实。',
      scrollHint: '向下滚动'
    },
    // 项目展示
    projects: {
      title: '项目展示',
      subtitle: '这里展示了我最近完成的一些项目，每个项目都代表了我对技术的热爱和追求',
      viewProject: '查看项目'
    },
    // 博客
    blog: {
      title: '技术博客',
      subtitle: '分享学习心得和开发经验，记录成长路上的点点滴滴',
      readMore: '阅读全文',
      minRead: '分钟'
    },
    // 主题切换
    theme: {
      dark: '深色模式',
      light: '浅色模式'
    },
    // 语言切换
    language: {
      zh: '中文',
      en: 'English'
    }
  },
  en: {
    // Hero Section
    hero: {
      title: "Hello, I'm a Developer",
      subtitle: "Passionate about creating elegant digital experiences, focused on building high-performance, user-friendly web applications. Let's turn ideas into reality together.",
      scrollHint: 'Scroll down'
    },
    // Projects
    projects: {
      title: 'Projects',
      subtitle: 'Here are some of my recent projects, each representing my passion and dedication to technology',
      viewProject: 'View Project'
    },
    // Blog
    blog: {
      title: 'Blog',
      subtitle: 'Sharing learning insights and development experience, documenting the journey of growth',
      readMore: 'Read More',
      minRead: 'min read'
    },
    // Theme
    theme: {
      dark: 'Dark Mode',
      light: 'Light Mode'
    },
    // Language
    language: {
      zh: '中文',
      en: 'English'
    }
  }
}

// 获取翻译函数
export const getTranslation = (lang: Language, key: string): string => {
  const keys = key.split('.')
  let value: Translations | string = translations[lang]
  
  for (const k of keys) {
    if (typeof value === 'object' && value !== null && k in value) {
      value = value[k]
    } else {
      return key // 如果找不到翻译，返回原始 key
    }
  }
  
  return typeof value === 'string' ? value : key
}

export type { Language, Translations }
export { translations }
